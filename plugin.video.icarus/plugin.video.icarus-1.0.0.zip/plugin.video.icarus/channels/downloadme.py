# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Icarus .- XBMC Plugin
# Canale downloadme
# https://alfa-addon.com/categories/icarus-addon.50/
# Version: 201804162230
# ------------------------------------------------------------
import re

from core import httptools, scrapertools
from core import servertools
from core.item import Item
from core.tmdb import infoIca
from platformcode import logger, config
from lib import unshortenit


__channel__ = "downloadme"

host = "https://www.downloadme.gratis"

headers = [['Referer', host]]


def mainlist(item):
    logger.info("[downloadme.py] mainlist")

    # Main options
    itemlist = [Item(channel=__channel__,
                     action="peliculas",
                     title="[COLOR azure]Film[/COLOR]",
                     url="%s/category/film/" % host,
                     extra="movie",
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="peliculas",
                     title="Serie TV",
                     text_color="azure",
                     url="%s/category/serie-tv/" % host,
                     extra="tv",
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="peliculas",
                     title="Anime",
                     text_color="azure",
                     url="%s/category/anime/" % host,
                     extra="tv",
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="categorie",
                     title="[COLOR azure]Categorie[/COLOR]",
                     url="%s/" % host,
                     extra="movie",
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png")]

    return itemlist


def categorie(item):
    logger.info("[downloadme.py] peliculas")
    itemlist = []

    if item.url == "":
        item.url = host

    data = httptools.downloadpage(item.url, headers=headers).data
    patron = '<li .*? menu-item-type-taxonomy menu-item-object-category menu-item-.*?"><a href="([^"]+)">([^<]+)<\/a><\/li>'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas",
                 text_color="azure",
                 fulltitle=scrapedtitle,
                 show=scrapedtitle,
                 title=scrapedtitle,
                 url=scrapedurl,
                 extra=item.extra,
                 viewmode="movie_with_plot",
                 Folder=True))

    return itemlist

def peliculas(item):
    logger.info("[downloadme.py] peliculas")
    itemlist = []

    data = httptools.downloadpage(item.url, headers=headers).data
    patron = r'<h\d+ class=[^<]+<a href="([^"]+)"[^>]*>([^<]+)</a>'
    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
        scrapedtitle = scrapedtitle.split("&#8211;")[0]
        scrapedtitle = scrapedtitle.split(" Download")[0]
        scrapedthumbnail = ""
        itemlist.append(infoIca(
            Item(channel=__channel__,
                 action="findvideos" if 'movie' in item.extra else 'episodes',
                 text_color="azure",
                 fulltitle=scrapedtitle,
                 show=scrapedtitle,
                 title=scrapedtitle,
                 url="%s/%s" % (host, scrapedurl),
                 viewmode="movie_with_plot",
                 thumbnail=scrapedthumbnail), tipo=item.extra))

    nextpage_regex = '<a class="next page-numbers" href="([^"]+)">'
    next_page = scrapertools.find_single_match(data, nextpage_regex)
    if next_page != "":
        itemlist.append(
            Item(channel=__channel__,
                 action="peliculas",
                 title="[COLOR lightgreen]" + config.get_localized_string(30992) + "[/COLOR]",
                 url="%s%s" % (host, next_page),
                 extra=item.extra,
                 thumbnail="http://2.bp.blogspot.com/-fE9tzwmjaeQ/UcM2apxDtjI/AAAAAAAAeeg/WKSGM2TADLM/s1600/pager+old.png"))
    return itemlist

def episodes(item):
    logger.info("[downloadme.py] tv_series")
    itemlist = []

    data = httptools.downloadpage(item.url, headers=headers).data
    patron = r'<a href="([^"]+)"[^>]*>([^<]+)</a>(?:<br>|</p>)'

    matches = re.compile(patron, re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
        if not scrapertools.find_single_match(scrapedtitle, r'\d+'): continue
        scrapedtitle = scrapertools.decodeHtmlentities(scrapedtitle)
        itemlist.append(
            Item(channel=__channel__,
                 action="findvideos",
                 text_color="azure",
                 contentType="episode",
                 fulltitle=scrapedtitle,
                 show=scrapedtitle,
                 title=scrapedtitle,
                 thumbnail=item.thumbnail,
                 url=scrapedurl,
                 viewmode="movie_with_plot"))

    return itemlist

def findvideos(item):
    logger.info("icarus.downloadme findvideos")
    itemlist = []

    if 'movie' in item.extra:
        # Carica la pagina 
        data = httptools.downloadpage(item.url, headers=headers).data

        url = scrapertools.find_single_match(data.lower(), r'<a\s*href="([^"]+)" target="_blank" rel="noopener">.*?link[^<]+</a>')
    else:
        url = item.url

    if 'zipansion' in url:
        url = httptools.downloadpage(url, follow_redirects=False).headers.get("location", "")
        url, c = unshortenit.unshorten_only(url)
        data = url

    itemlist = servertools.find_video_items(data=data)

    for videoitem in itemlist:
        videoitem.title = item.title + videoitem.title
        videoitem.fulltitle = item.fulltitle
        videoitem.thumbnail = item.thumbnail
        videoitem.show = item.show
        videoitem.plot = item.plot
        videoitem.channel = __channel__

    return itemlist

