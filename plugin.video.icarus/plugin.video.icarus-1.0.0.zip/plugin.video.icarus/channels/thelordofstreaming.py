# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Icarus - XBMC Plugin
# Canale per Thelordofstreaming
# https://alfa-addon.com/categories/icarus-addon.50/
# ----------------------------------------------------------

import re

from platformcode import logger, config
from core import servertools, httptools, scrapertools
from core.item import Item
from core.tmdb import infoIca

__channel__ = "thelordofstreaming"

host = "http://www.thelordofstreaming.it/"


# ----------------------------------------------------------------------------------------------------------------
def mainlist(item):
    logger.info("Icarus [thelordofstreaming.py]==> Mainlist")
    itemlist = [Item(channel=__channel__,
                     action="movies",
                     title="Film",
                     text_color="azure",
                     url="%s/category/movie/" % host,
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="movies",
                     title="Wrestling",
                     text_color="azure",
                     url="%s/category/wrestling/" % host,
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png"),
                Item(channel=__channel__,
                     action="tvseries",
                     title="Serie TV",
                     text_color="azure",
                     url="%s/serie-tv/" % host,
                     thumbnail="http://orig03.deviantart.net/6889/f/2014/079/7/b/movies_and_popcorn_folder_icon_by_matheusgrilo-d7ay4tw.png")]

    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def movies(item):
    logger.info("Icarus [thelordofstreaming.py]==> Movies")
    itemlist = []

    data = httptools.downloadpage(item.url).data
    blocco = scrapertools.find_single_match(data, r'<nav id="nav-above">(.*?)</section><!-- #primary -->')
    patron = r'<article id="post-\d+"(.*?)</article>'
    matches = re.findall(patron, blocco, re.DOTALL)

    for match in matches:
        scrapedtitle = re.findall(r'<h1 class="entry-title">[^>]+>([^<]+)</a></h1>', match, re.DOTALL)[0]
        scrapedurl = re.findall(r'<h1 class="entry-title"><a href="([^"]+)"[^>]+>[^<]+</a></h1>', match, re.DOTALL)[0]
        scrapedthumbnail = re.findall(r'<img class="[^"]+"\s*src="([^"]+)"[^>]+>', match, re.DOTALL)[0]
        urls = scrapertools.find_single_match(match, r'<p>(.*?)</p>')

        itemlist.append(infoIca(
            Item(channel=__channel__,
                 action="findvideos",
                 text_color="azure",
                 contentType="movie",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedurl,
                 extra=urls,
                 thumbnail=scrapedthumbnail,
                 folder=True), tipo="movie"))

    patronvideos = r'<div class="nav-previous"><a href="([^"]+)"[^>]*><span class="meta-nav">&larr;</span> Articoli più vecchi</a></div>'
    matches = re.compile(patronvideos, re.DOTALL).findall(data)

    if len(matches) > 0:
        scrapedurl = matches[0]
        if config.is_xbmc():
            itemlist.append(
                Item(channel=__channel__,
                    action="HomePage",
                    title=color("Torna Home", "yellow"),
                    folder=True))
        itemlist.append(
            Item(channel=__channel__,
                 action="movies",
                 title="[COLOR lightgreen]" + config.get_localized_string(30992) + "[/COLOR]",
                 url=scrapedurl,
                 thumbnail="http://2.bp.blogspot.com/-fE9tzwmjaeQ/UcM2apxDtjI/AAAAAAAAeeg/WKSGM2TADLM/s1600/pager+old.png",
                 folder=True))

    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def tvseries(item):
    logger.info("Icarus [thelordofstreaming.py]==> TVSeries")
    itemlist = []

    data = httptools.downloadpage(item.url).data
    blocco = scrapertools.find_single_match(data, r'<div class="entry-content">\s*<ul>(.*?)</ul>')
    patron = r'<li><a href="([^"]+)"[^>]*>([^<]+)</a></li>'
    matches = re.findall(patron, blocco, re.DOTALL)

    for scrapedurl, scrapedtitle in matches:
        scrapedtitle = scrapertools.decodeHtmlentities(scrapedtitle).strip()
        itemlist.append(
            Item(channel=__channel__,
                 action="episodes",
                 text_color="azure",
                 contentType="tvshow",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedurl,
                 show=scrapedtitle,
                 folder=True))

    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def episodes(item):
    logger.info("Icarus [thelordofstreaming.py]==> Episodes")
    itemlist = []

    data = httptools.downloadpage(item.url).data
    blocco = scrapertools.find_single_match(data, r'<div class="entry-content">(.*?)</div>')
    patron = r'(\d+\&\#215\;\d+)(.*?)(?:<br \/>|<span style="color: #\d+;"><em>FINE</em>)'
    matches = re.findall(patron, blocco, re.DOTALL)

    for scrapedtitle, scrapedlinks in matches:
        scrapedtitle = scrapertools.decodeHtmlentities(scrapedtitle).strip()
        itemlist.append(
            Item(channel=__channel__,
                 action="findvideos",
                 text_color="azure",
                 contentType="episode",
                 title=scrapedtitle,
                 fulltitle=scrapedtitle,
                 url=scrapedlinks,
                 extra="",
                 folder=True))

    if config.get_videolibrary_support() and len(itemlist) != 0:
        itemlist.append(
            Item(channel=__channel__,
                 title=config.get_localized_string(30161),
                 url=item.url,
                 action="add_serie_to_library",
                 extra="episodes",
                 show=item.show))

    return itemlist

# ================================================================================================================

# ----------------------------------------------------------------------------------------------------------------
def findvideos(item):
    logger.info("Icarus [thelordofstreaming.py]==> Findvideos")

    if item.extra and item.extra != "page":
        itemlist = servertools.find_video_items(data=item.extra)
    elif item.extra and item.extra == "page":
        itemlist = servertools.find_video_items(data=httptools.downloadpage(item.url).data)
    else:
        itemlist = servertools.find_video_items(data=item.url)

    for videoitem in itemlist:
        server = re.sub(r'[-\[\]\s]+', '', videoitem.title)
        videoitem.text_color = "azure"
        videoitem.title = "".join(["[%s] " % color(server.capitalize(), 'orange'), item.title])
        videoitem.fulltitle = item.fulltitle
        videoitem.show = item.show
        videoitem.thumbnail = item.thumbnail
        videoitem.channel = __channel__
    return itemlist

# ================================================================================================================

def color(text, color):
    return "[COLOR %s]%s[/COLOR]" % (color, text)

def HomePage(item):
    import xbmc
    xbmc.executebuiltin("ReplaceWindow(10024,plugin://plugin.video.icarus)")

