# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Icarus - XBMC Plugin
# Script per la ricerca di un canale in base al testo inserito
# https://alfa-addon.com/categories/icarus-addon.50/
# Icarus By iSOD
# ------------------------------------------------------------

import os, glob

from platformcode import config, logger
from core import channeltools
from core.item import Item


def search(item, texto):
    logger.info("[searchchannel.py] search texto=" + texto)
    itemlist = []

    directory = os.path.join(config.get_runtime_path(), "channels", '*.json')
    files = glob.glob(directory)
    for file in files:
        file = os.path.basename(file).replace(".json", "")
        channel_parameters = channeltools.get_channel_parameters(file)
        if channel_parameters['active'] == True:
            texto = texto.lower().replace(" ", "")
            name = channel_parameters['title'].lower().replace(" ", "")
            if texto in name:
                itemlist.append(Item(title=channel_parameters['title'], text_color="azure", action="mainlist", channel=file,
                                     thumbnail=channel_parameters["thumbnail"], type="generic", viewmode="list"))

    return itemlist
