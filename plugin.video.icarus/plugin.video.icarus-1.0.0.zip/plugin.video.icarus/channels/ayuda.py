# -*- coding: utf-8 -*-
# Icarus - Kodi Addon
# ----------------------------------------------------------------------
# Icarus - XBMC Plugin
# ayuda - Videos de ayuda y tutoriales para Icarus
# https://alfa-addon.com/categories/icarus-addon.50/
# contribucion de jurrabi
# ----------------------------------------------------------------------

import os, xbmc, xbmcgui
from channels import youtube_channel
from platformcode import config, logger, platformtools
from core import filetools, scrapertools
from core.item import Item

# =======================================================
# Impostazioni
# --------------------------------------------------------
ram = [config.get_localized_string(60400), config.get_localized_string(60401), config.get_localized_string(60402), config.get_localized_string(60403)]
opt = ['20971520', '52428800', '157286400', '209715200']
# =======================================================

def mainlist(item):
    logger.info("icarus.channels.ayuda mainlist")

    itemlist = []

    cuantos = 0
    if config.is_xbmc():
        addon_name = config.get_localized_string(20000)
        itemlist.append(Item(channel=item.channel, action="reset",
                             thumbnail=os.path.join(config.get_runtime_path() , "resources" , "images", "reset_sod.png"),
                             title=config.get_localized_string(60393) % addon_name,plot=config.get_localized_string(60392) % addon_name))                     
        cuantos += cuantos

    return itemlist


def tutoriales(item):
    playlists = youtube_channel.playlists(item, "tvalacarta")

    itemlist = []

    for playlist in playlists:
        if playlist.title == "Tutorial di icarus":
            itemlist = youtube_channel.videos(playlist)

    return itemlist

def reset(item):
    logger.info("icarus.channels.ayuda reset")
    itemlist = []
    addon_name = config.get_localized_string(20000)
    risp = platformtools.dialog_yesno(config.get_localized_string(60394) % addon_name," ",config.get_localized_string(60395) % addon_name," ",nolabel=config.get_localized_string(60396), yeslabel=config.get_localized_string(60397))
    if risp == 0: 
        logger.info("Annulla")
    if risp == 1: 
        logger.info("Conferma")
        path=xbmc.translatePath("special://profile/addon_data/plugin.video.icarus")
        filetools.rmdirtree(path)
        config.verify_directories_created()   
        platformtools.dialog_ok(config.get_localized_string(60394) % addon_name," ",config.get_localized_string(60398)," ")

    return platformtools.itemlist_refresh()


def force_creation_advancedsettings(item):
    # advancedsettings path
    advancedsettings = xbmc.translatePath("special://userdata/advancedsettings.xml")
    itemlist = []

    try:
        risp = platformtools.dialog_select(config.get_localized_string(60404), [ram[0], ram[1], ram[2], ram[3]])
        #logger.info(str(risp))
        if risp == 0:
            valore = opt[0]
            testo = config.get_localized_string(60405)
        if risp == 1:
            valore = opt[1]
            testo = config.get_localized_string(60406)
        if risp == 2:
            valore = opt[2]
            testo = config.get_localized_string(60407)
        if risp == 3:
            valore = opt[3]
            testo = config.get_localized_string(60408)
        if risp < 0:
            return itemlist

        file = '''<advancedsettings>
                    <network>
                        <buffermode>1</buffermode>
                        <cachemembuffersize>''' + valore + '''</cachemembuffersize>
                        <readbufferfactor>10</readbufferfactor>
                        <autodetectpingtime>30</autodetectpingtime>
                        <curlclienttimeout>60</curlclienttimeout>
                        <curllowspeedtime>60</curllowspeedtime>
                        <curlretries>2</curlretries>
                        <disableipv6>true</disableipv6>
                    </network>
                    <gui>
                        <algorithmdirtyregions>0</algorithmdirtyregions>
                        <nofliptimeout>0</nofliptimeout>
                    </gui>
                        <playlistasfolders1>false</playlistasfolders1>
                    <audio>
                        <defaultplayer>dvdplayer</defaultplayer>
                    </audio>
                        <imageres>540</imageres>
                        <fanartres>720</fanartres>
                        <splash>false</splash>
                        <handlemounting>0</handlemounting>
                    <samba>
                        <clienttimeout>30</clienttimeout>
                    </samba>
                </advancedsettings>'''
        logger.info(file)
        salva = open(advancedsettings, "w")
        salva.write(file)
        salva.close()
    except:
        pass

    platformtools.dialog_ok(config.get_localized_string(60409), config.get_localized_string(60410),config.get_localized_string(60411), testo)

    return platformtools.itemlist_refresh()

def force_creation_advancedsettings_17(item):
    # advancedsettings path
    advancedsettings = xbmc.translatePath("special://userdata/advancedsettings.xml")
    itemlist=[]
    try:
        risp = platformtools.dialog_select(config.get_localized_string(60404), [ram[0], ram[1], ram[2], ram[3]])
        logger.info(str(risp))

        if risp == 0:
            valore = opt[0]
            testo = config.get_localized_string(60405)
        if risp == 1:
            valore = opt[1]
            testo = config.get_localized_string(60406)
        if risp == 2:
            valore = opt[2]
            testo = config.get_localized_string(60407)
        if risp == 3:
            valore = opt[3]
            testo = config.get_localized_string(60408)
        if risp < 0:
            return itemlist


        file = '''<advancedsettings>
                    <network>
                        <autodetectpingtime>30</autodetectpingtime>
                        <curlclienttimeout>60</curlclienttimeout>
                        <curllowspeedtime>60</curllowspeedtime>
                        <curlretries>2</curlretries>
                        <disableipv6>true</disableipv6>
                    </network>
                    <cache>
                        <buffermode>1</buffermode>
                        <memorysize>''' + valore + '''</memorysize>
                        <readfactor>10</readfactor>
                    </cache>
                    <gui>
                        <algorithmdirtyregions>0</algorithmdirtyregions>
                        <nofliptimeout>0</nofliptimeout>
                    </gui>
                        <playlistasfolders1>false</playlistasfolders1>
                    <audio>
                        <defaultplayer>dvdplayer</defaultplayer>
                    </audio>
                        <imageres>540</imageres>
                        <fanartres>720</fanartres>
                        <splash>false</splash>
                        <handlemounting>0</handlemounting>
                    <samba>
                        <clienttimeout>30</clienttimeout>
                    </samba>
                </advancedsettings>'''
        logger.info(file)
        salva = open(advancedsettings, "w")

        salva.write(file)
        salva.close()
    except:
        pass

    platformtools.dialog_ok(config.get_localized_string(60409), config.get_localized_string(60410),config.get_localized_string(60411), testo)

    return platformtools.itemlist_refresh()

def Leggi_Parametro():
    logger.info("icarus.channels.ayuda Leggi_Parametro")
    itemlist=[]

    advancedsettings = xbmc.translatePath("special://userdata/advancedsettings.xml")

    if os.path.exists(advancedsettings):
        infile = open(advancedsettings, "rb")
        data = infile.read()
        infile.close()


        if scrapertools.find_single_match(data, "<memorysize>([^<]*)</memorysize>")=='':
            if scrapertools.find_single_match(data, "<cachemembuffersize>([^<]*)</cachemembuffersize>")==opt[0]:
                return ram[0]
            elif scrapertools.find_single_match(data, "<cachemembuffersize>([^<]*)</cachemembuffersize>")==opt[1]:
                return ram[1]
            elif scrapertools.find_single_match(data, "<cachemembuffersize>([^<]*)</cachemembuffersize>")==opt[2]:
                return ram[2]
            elif scrapertools.find_single_match(data, "<cachemembuffersize>([^<]*)</cachemembuffersize>")==opt[3]:
                return ram[3]

        else:
            if scrapertools.find_single_match(data, "<memorysize>([^<]*)</memorysize>")==opt[0]:
                return ram[0]
            elif scrapertools.find_single_match(data, "<memorysize>([^<]*)</memorysize>")==opt[1]:
                return ram[1]
            elif scrapertools.find_single_match(data, "<memorysize>([^<]*)</memorysize>")==opt[2]:
                return ram[2]
            elif scrapertools.find_single_match(data, "<memorysize>([^<]*)</memorysize>")==opt[3]:
                return ram[3]
    return " - "
